class_name UiKit
extends RefCounted

static func style_button(b: Button, accent: Color = Color(0.35, 0.8, 1.0)) -> void:
	for n in ["normal", "hover", "pressed", "focus"]:
		var s := StyleBoxFlat.new()
		s.bg_color = accent.darkened(0.55) if n == "pressed" else Color(0.06, 0.08, 0.2)
		s.border_color = accent
		s.set_border_width_all(4)
		s.set_content_margin_all(8)
		b.add_theme_stylebox_override(n, s)
	b.add_theme_font_size_override("font_size", 26)
	b.custom_minimum_size = Vector2(340, 54)

static func outline_label(l: Label, size: int, col: Color = Color.WHITE) -> void:
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
