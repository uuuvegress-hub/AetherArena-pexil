extends Node2D
# Battle scene: builds arena, fighters, HUD, touch controls and handles effects / round end.

var world: Node2D
var hud: CanvasLayer
var p1: Fighter
var p2: Fighter
var training := false
var over := false
var shake := 0.0
var last_vis := Vector2.ZERO
var bar_hp1: Array
var bar_hp2: Array
var bar_en1: Array
var bar_en2: Array
var name1: Label
var name2: Label
var menu_btn: Button
var btns := {}
var sparks: Array = []
var spark_i := 0

func _ready() -> void:
	training = GameManager.mode == "training"
	world = Node2D.new()
	add_child(world)
	var bg := Sprite2D.new()
	bg.texture = load("res://arenas/crystal_valley/background.png")
	bg.position = Vector2(480, 270)
	world.add_child(bg)
	p1 = Fighter.new()
	p1.setup(GameManager.player_char, true)
	p1.position = Vector2(300, Fighter.FLOOR_Y)
	p2 = Fighter.new()
	p2.setup(GameManager.opponent_char(), false)
	p2.position = Vector2(660, Fighter.FLOOR_Y)
	p2.brain = EnemyAI.new(p2, "dummy" if training else GameManager.difficulty)
	p1.opponent = p2
	p2.opponent = p1
	world.add_child(p1)
	world.add_child(p2)
	for f in [p1, p2]:
		f.spawn_projectile.connect(_on_projectile)
		f.hit_landed.connect(_on_hit)
		f.died.connect(_on_died)
	for i in 8:
		var s := CPUParticles2D.new()
		s.one_shot = true
		s.emitting = false
		s.amount = 16
		s.lifetime = 0.4
		s.explosiveness = 1.0
		s.spread = 180.0
		s.gravity = Vector2(0, 700)
		s.initial_velocity_min = 140.0
		s.initial_velocity_max = 340.0
		s.scale_amount_min = 3.0
		s.scale_amount_max = 6.0
		world.add_child(s)
		sparks.append(s)
	_build_hud()
	_build_controls()

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	bar_hp1 = _bar(Color(0.2, 0.9, 0.3))
	bar_hp2 = _bar(Color(0.95, 0.3, 0.25))
	bar_en1 = _bar(Color(0.3, 0.6, 1.0))
	bar_en2 = _bar(Color(0.3, 0.6, 1.0))
	name1 = Label.new()
	name2 = Label.new()
	name1.text = p1.data["name"]
	name2.text = p2.data["name"] + ("  (TRAINING DUMMY)" if training else "")
	name2.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	for l in [name1, name2]:
		UiKit.outline_label(l, 20)
		l.size = Vector2(360, 26)
		hud.add_child(l)
	menu_btn = Button.new()
	menu_btn.text = "MENU"
	UiKit.style_button(menu_btn)
	menu_btn.custom_minimum_size = Vector2(100, 40)
	menu_btn.add_theme_font_size_override("font_size", 18)
	menu_btn.pressed.connect(func(): GameManager.goto("res://scenes/main_menu.tscn"))
	hud.add_child(menu_btn)

func _bar(col: Color) -> Array:
	var back := ColorRect.new()
	back.color = Color(0.05, 0.05, 0.1, 0.9)
	var fill := ColorRect.new()
	fill.color = col
	hud.add_child(back)
	hud.add_child(fill)
	return [back, fill]

func _place(bar: Array, pos: Vector2, w: float, h: float, ratio: float, right: bool) -> void:
	bar[0].position = pos - Vector2(3, 3)
	bar[0].size = Vector2(w + 6.0, h + 6.0)
	var fw := w * clampf(ratio, 0.0, 1.0)
	bar[1].size = Vector2(fw, h)
	bar[1].position = pos + Vector2((w - fw) if right else 0.0, 0.0)

func _build_controls() -> void:
	_make_btn("move_left", "<", 104.0, true)
	_make_btn("move_right", ">", 104.0, true)
	_make_btn("jump", "JUMP", 96.0, false)
	_make_btn("attack", "ATK", 116.0, false)
	_make_btn("blast", "BLAST", 92.0, false)
	_make_btn("block", "BLOCK", 92.0, false)
	_make_btn("special", "ULT", 92.0, false)

func _make_btn(action: String, text: String, size: float, passby: bool) -> void:
	var b := TouchScreenButton.new()
	b.texture_normal = load("res://ui/btn.png")
	b.texture_pressed = load("res://ui/btn_down.png")
	b.action = action
	b.passby_press = passby
	b.scale = Vector2(size / 96.0, size / 96.0)
	b.modulate = Color(1, 1, 1, 0.72)
	var l := Label.new()
	l.text = text
	l.size = Vector2(96, 96)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiKit.outline_label(l, 22)
	b.add_child(l)
	hud.add_child(b)
	btns[action] = [b, size]

func _layout_controls(v: Vector2) -> void:
	var h := v.y
	_put("move_left", Vector2(22, h - 128))
	_put("move_right", Vector2(142, h - 128))
	_put("jump", Vector2(82, h - 236))
	_put("attack", Vector2(v.x - 140, h - 140))
	_put("blast", Vector2(v.x - 258, h - 118))
	_put("block", Vector2(v.x - 130, h - 262))
	_put("special", Vector2(v.x - 248, h - 236))

func _put(action: String, pos: Vector2) -> void:
	btns[action][0].position = pos

func _process(d: float) -> void:
	var v := get_viewport_rect().size
	if v != last_vis:
		last_vis = v
		_layout_controls(v)
	shake = move_toward(shake, 0.0, 40.0 * d)
	world.position = Vector2((v.x - 960.0) / 2.0, 0.0) + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake
	var bw := minf(v.x * 0.4, 400.0)
	_place(bar_hp1, Vector2(20, 18), bw, 22, p1.hp / p1.max_hp, false)
	_place(bar_hp2, Vector2(v.x - 20.0 - bw, 18), bw, 22, p2.hp / p2.max_hp, true)
	_place(bar_en1, Vector2(20, 46), bw * 0.7, 10, p1.energy / 100.0, false)
	_place(bar_en2, Vector2(v.x - 20.0 - bw * 0.7, 46), bw * 0.7, 10, p2.energy / 100.0, true)
	bar_en1[1].color = Color(1.0, 0.85, 0.2) if p1.energy >= 50.0 else Color(0.3, 0.6, 1.0)
	bar_en2[1].color = Color(1.0, 0.85, 0.2) if p2.energy >= 50.0 else Color(0.3, 0.6, 1.0)
	name1.position = Vector2(20, 62)
	name2.position = Vector2(v.x - 20.0 - 360.0, 62)
	menu_btn.position = Vector2(v.x / 2.0 - 50.0, 14)
	if training:
		p1.add_energy(60.0 * d)
		if p2.hp < 30.0:
			p2.hp = p2.max_hp
			p2.hp_changed.emit(p2.hp, p2.max_hp)

func _physics_process(_d: float) -> void:
	# keep fighters from standing inside each other
	if p1.grounded and p2.grounded:
		var dx := p2.position.x - p1.position.x
		if absf(dx) < 44.0:
			var push := (44.0 - absf(dx)) * 0.5
			var s := 1.0 if dx >= 0.0 else -1.0
			p1.position.x -= s * push
			p2.position.x += s * push

func _on_projectile(p) -> void:
	world.add_child(p)

func _on_hit(pos: Vector2, heavy: bool, blocked: bool) -> void:
	shake = maxf(shake, 12.0 if heavy else (2.0 if blocked else 5.0))
	var s: CPUParticles2D = sparks[spark_i % sparks.size()]
	spark_i += 1
	s.position = pos
	s.color = Color(0.7, 0.8, 1.0) if blocked else (Color(1.0, 0.6, 0.2) if heavy else Color(1.0, 0.95, 0.6))
	s.restart()

func _on_died(f) -> void:
	if over:
		return
	over = true
	Engine.time_scale = 0.35
	await get_tree().create_timer(0.9, true, false, true).timeout
	Engine.time_scale = 1.0
	var win: bool = f == p2
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 14)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.add_child(box)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	var title := Label.new()
	title.text = "YOU WIN!" if win else "YOU LOSE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiKit.outline_label(title, 64, Color(1, 0.9, 0.3) if win else Color(1, 0.4, 0.4))
	box.add_child(title)
	var again := Button.new()
	again.text = "REMATCH"
	var menu := Button.new()
	menu.text = "MAIN MENU"
	for b in [again, menu]:
		UiKit.style_button(b)
		box.add_child(b)
	again.pressed.connect(func():
		Engine.time_scale = 1.0
		get_tree().reload_current_scene())
	menu.pressed.connect(func(): GameManager.goto("res://scenes/main_menu.tscn"))
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	layer.add_child(dim)
	layer.add_child(center)

func _exit_tree() -> void:
	Engine.time_scale = 1.0
