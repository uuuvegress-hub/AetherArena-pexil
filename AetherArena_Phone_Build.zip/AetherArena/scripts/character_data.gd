class_name CharacterData
extends RefCounted

const FRAME_W := 48
const FRAME_H := 64
const ROWS := ["idle", "walk", "jump", "attack", "attack2", "hurt", "block", "cast", "dead"]
const FRAMES := {"idle": 4, "walk": 6, "jump": 2, "attack": 3, "attack2": 3, "hurt": 1, "block": 1, "cast": 3, "dead": 1}
const FPS := {"idle": 6.0, "walk": 11.0}

const ROSTER := {
	"aether_knight": {
		"name": "Aether Knight", "hp": 100.0, "speed": 310.0,
		"punch": 7.0, "blast_dmg": 9.0, "blast_speed": 640.0, "blast_cd": 0.8, "special_dmg": 24.0,
		"color": Color(0.35, 0.8, 1.0),
		"desc": "Fast and balanced. Fires fast energy blasts.",
		"stats": {"Power": 3, "Speed": 4, "Defense": 3},
	},
	"inferno": {
		"name": "Inferno", "hp": 115.0, "speed": 235.0,
		"punch": 10.0, "blast_dmg": 12.0, "blast_speed": 470.0, "blast_cd": 1.1, "special_dmg": 30.0,
		"color": Color(1.0, 0.55, 0.15),
		"desc": "Slow but brutal. Heavy fire attacks.",
		"stats": {"Power": 5, "Speed": 2, "Defense": 4},
	},
}

static func ids() -> Array:
	return ROSTER.keys()

static func build_frames(id: String) -> SpriteFrames:
	var tex: Texture2D = load("res://characters/%s/sheet.png" % id)
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for r in ROWS.size():
		var n: String = ROWS[r]
		sf.add_animation(n)
		sf.set_animation_speed(n, FPS.get(n, 1.0))
		sf.set_animation_loop(n, n == "idle" or n == "walk")
		for c in FRAMES[n]:
			var at := AtlasTexture.new()
			at.atlas = tex
			at.region = Rect2(c * FRAME_W, r * FRAME_H, FRAME_W, FRAME_H)
			sf.add_frame(n, at)
	return sf
