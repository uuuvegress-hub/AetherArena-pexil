extends Node
# Autoload: global game settings + input map registration.

var player_char := "aether_knight"
var difficulty := "normal"   # easy / normal / hard
var mode := "fight"          # fight / training

func _ready() -> void:
	_setup_input()

func opponent_char() -> String:
	return "inferno" if player_char == "aether_knight" else "aether_knight"

func goto(path: String) -> void:
	Engine.time_scale = 1.0
	get_tree().change_scene_to_file(path)

func _setup_input() -> void:
	var map := {
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"jump": [KEY_W, KEY_UP, KEY_SPACE], "attack": [KEY_J],
		"blast": [KEY_K], "block": [KEY_L], "special": [KEY_U],
	}
	for a in map:
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		for k in map[a]:
			var e := InputEventKey.new()
			e.physical_keycode = k
			InputMap.action_add_event(a, e)
