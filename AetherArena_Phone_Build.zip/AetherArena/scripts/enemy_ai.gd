class_name EnemyAI
extends RefCounted
# Simple state-based AI. Difficulty changes reaction time and aggression.

const PROFILES := {
	"easy": {"react": 0.6, "aggr": 0.35, "block": 0.12, "blast": 0.2, "special": 0.15},
	"normal": {"react": 0.35, "aggr": 0.6, "block": 0.4, "blast": 0.4, "special": 0.4},
	"hard": {"react": 0.16, "aggr": 0.85, "block": 0.7, "blast": 0.6, "special": 0.7},
}

var f = null
var prof := {}
var dummy := false
var plan := "wait"
var plan_t := 0.0
var atk_timer := 0.0

func _init(fighter, difficulty: String) -> void:
	f = fighter
	dummy = difficulty == "dummy"
	prof = PROFILES.get(difficulty, PROFILES["normal"])

func think(d: float) -> void:
	f.mv = 0.0
	f.h_block = false
	if dummy or f.opponent == null or f.state == "dead" or f.opponent.state == "dead":
		return
	var o = f.opponent
	var dx: float = o.position.x - f.position.x
	var dist := absf(dx)
	var toward := 1.0 if dx > 0.0 else -1.0
	plan_t -= d
	atk_timer -= d
	if plan_t <= 0.0:
		_choose(dist, o)
	match plan:
		"approach":
			f.mv = toward
		"retreat":
			f.mv = -toward
			if (f.position.x < 100.0 or f.position.x > 860.0) and f.grounded:
				f.p_jump = true
				plan = "approach"
		"attack":
			if dist > 95.0:
				f.mv = toward
			elif atk_timer <= 0.0:
				f.p_attack = true
				atk_timer = randf_range(0.15, 0.35)
		"block":
			f.h_block = true
		"blast":
			if f.cd_blast <= 0.0:
				f.p_blast = true
			plan = "wait"
			plan_t = 0.3
		"special":
			if f.energy >= 50.0:
				f.p_special = true
			plan = "wait"
			plan_t = 0.4
		"jump":
			if f.grounded:
				f.p_jump = true
			f.mv = toward
			plan = "approach"
			plan_t = 0.4

func _choose(dist: float, o) -> void:
	plan_t = float(prof["react"]) * randf_range(0.7, 1.4)
	var r := randf()
	var threat: bool = o.state == "attack" or o.state == "cast"
	if threat and dist < 140.0 and randf() < float(prof["block"]):
		plan = "block"
		plan_t = 0.35
		return
	if f.energy >= 50.0 and dist > 120.0 and randf() < float(prof["special"]) * 0.5:
		plan = "special"
		return
	if dist > 300.0 and f.cd_blast <= 0.0 and randf() < float(prof["blast"]):
		plan = "blast"
		return
	var aggr := float(prof["aggr"])
	if dist > 130.0:
		if r < aggr:
			plan = "approach"
		elif r < aggr + 0.15:
			plan = "jump"
		else:
			plan = "wait"
	else:
		if r < aggr:
			plan = "attack"
			plan_t *= 2.0
		elif r < aggr + 0.2:
			plan = "retreat"
		else:
			plan = "wait"
