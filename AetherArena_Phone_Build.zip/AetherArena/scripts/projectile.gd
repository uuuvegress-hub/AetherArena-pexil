class_name Projectile
extends Node2D
# Energy blast. Damage is applied through target.take_hit().

var shooter = null
var target = null
var dir := 1
var dmg := 8.0
var speed := 600.0
var radius := 12.0
var col := Color.WHITE
var heavy := false
var life := 3.0

func setup(p_shooter, p_target, p_dir: int, p_dmg: float, p_speed: float, p_radius: float, p_col: Color, p_heavy: bool) -> void:
	shooter = p_shooter
	target = p_target
	dir = p_dir
	dmg = p_dmg
	speed = p_speed
	radius = p_radius
	col = p_col
	heavy = p_heavy

func _physics_process(d: float) -> void:
	position.x += dir * speed * d
	life -= d
	queue_redraw()
	if life <= 0.0 or target == null or target.state == "dead":
		queue_free()
		return
	var r := Rect2(position - Vector2(radius, radius), Vector2(radius, radius) * 2.0)
	if r.intersects(target.hurt_rect()):
		var kb := Vector2(dir * (480.0 if heavy else 260.0), -240.0 if heavy else -80.0)
		target.take_hit(dmg, kb, 0.55 if heavy else 0.3, heavy)
		shooter.add_energy(dmg * 0.6)
		queue_free()

func _draw() -> void:
	draw_line(Vector2(-dir * radius * 3.0, 0), Vector2(-dir * radius, 0), Color(col, 0.45), radius * 1.2)
	draw_circle(Vector2.ZERO, radius * 1.7, Color(col, 0.18))
	draw_circle(Vector2.ZERO, radius * 1.3, Color(col, 0.4))
	draw_circle(Vector2.ZERO, radius, col)
	draw_circle(Vector2.ZERO, radius * 0.5, Color.WHITE)
