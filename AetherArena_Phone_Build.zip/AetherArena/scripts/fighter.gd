class_name Fighter
extends Node2D
# Combat character: movement, 3-hit combo, block, energy blast, ultimate, damage, knockback.

signal hp_changed(cur: float, mx: float)
signal energy_changed(cur: float)
signal hit_landed(pos: Vector2, heavy: bool, blocked: bool)
signal spawn_projectile(p)
signal died(f)

const FLOOR_Y := 472.0
const GRAVITY := 1900.0
const MIN_X := 70.0
const MAX_X := 890.0

var id := ""
var data := {}
var is_player := false
var opponent = null
var brain = null
var hp := 100.0
var max_hp := 100.0
var energy := 0.0
var facing := 1
var state := "idle"
var t := 0.0
var vel := Vector2.ZERO
var grounded := true
var combo_step := 0
var hit_done := false
var queued_attack := false
var cd_blast := 0.0
var stun_time := 0.3
var inv := 0.0
var cast_special := false
var spawned := false
var flash := 0.0
# input flags (written by player polling or by the AI brain)
var mv := 0.0
var p_jump := false
var p_attack := false
var p_blast := false
var p_special := false
var h_block := false
var sprite: AnimatedSprite2D

func setup(char_id: String, player: bool) -> void:
	id = char_id
	data = CharacterData.ROSTER[char_id]
	is_player = player
	max_hp = data["hp"]
	hp = max_hp
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = CharacterData.build_frames(char_id)
	sprite.scale = Vector2(2, 2)
	sprite.position = Vector2(0, -64)
	add_child(sprite)
	sprite.play("idle")

func hurt_rect() -> Rect2:
	return Rect2(position.x - 26.0, position.y - 112.0, 52.0, 112.0)

func add_energy(a: float) -> void:
	energy = minf(100.0, energy + a)
	energy_changed.emit(energy)

func _physics_process(d: float) -> void:
	if brain != null:
		brain.think(d)
	elif is_player:
		_read_player()
	t += d
	cd_blast = maxf(0.0, cd_blast - d)
	inv = maxf(0.0, inv - d)
	if flash > 0.0:
		flash -= d
		sprite.modulate = Color(2, 2, 2) if flash > 0.0 else Color.WHITE
	if opponent != null and state in ["idle", "walk", "jump", "block"]:
		facing = 1 if opponent.position.x >= position.x else -1
	sprite.flip_h = facing < 0
	match state:
		"idle", "walk", "jump": _tick_free(d)
		"block": _tick_block(d)
		"attack": _tick_attack(d)
		"cast": _tick_cast(d)
		"hurt": _tick_hurt(d)
		"dead":
			vel.x = move_toward(vel.x, 0.0, 1500.0 * d)
			_pose("dead", 0)
	vel.y += GRAVITY * d
	position += vel * d
	if position.y >= FLOOR_Y and vel.y >= 0.0:
		position.y = FLOOR_Y
		vel.y = 0.0
		grounded = true
	else:
		grounded = false
	position.x = clampf(position.x, MIN_X, MAX_X)
	p_jump = false
	p_attack = false
	p_blast = false
	p_special = false

func _read_player() -> void:
	mv = Input.get_axis("move_left", "move_right")
	p_jump = Input.is_action_just_pressed("jump")
	p_attack = Input.is_action_just_pressed("attack")
	p_blast = Input.is_action_just_pressed("blast")
	p_special = Input.is_action_just_pressed("special")
	h_block = Input.is_action_pressed("block")

func _enter(s: String) -> void:
	state = s
	t = 0.0

func _pose(n: String, f: int) -> void:
	if sprite.animation != n:
		sprite.animation = n
	if sprite.is_playing():
		sprite.pause()
	sprite.frame = f

func _play(n: String) -> void:
	if sprite.animation != n or not sprite.is_playing():
		sprite.play(n)

func _tick_free(d: float) -> void:
	if h_block and grounded:
		_enter("block")
		vel.x = 0.0
		return
	if p_attack:
		_start_attack(1)
		return
	if p_blast and cd_blast <= 0.0:
		_start_cast(false)
		return
	if p_special and energy >= 50.0:
		_start_cast(true)
		return
	if p_jump and grounded:
		vel.y = -760.0
	vel.x = mv * float(data["speed"])
	if not grounded:
		state = "jump"
		_pose("jump", 0 if vel.y < 0.0 else 1)
	elif absf(mv) > 0.1:
		state = "walk"
		_play("walk")
	else:
		state = "idle"
		_play("idle")

func _tick_block(d: float) -> void:
	vel.x = move_toward(vel.x, 0.0, 1200.0 * d)
	_pose("block", 0)
	if not h_block:
		_enter("idle")

func _start_attack(step: int) -> void:
	combo_step = step
	_enter("attack")
	hit_done = false
	queued_attack = false

func _tick_attack(d: float) -> void:
	var finisher := combo_step == 3
	var w := 0.14 if finisher else 0.09
	var a := 0.09
	var r := 0.32 if finisher else 0.2
	var anim := "attack2" if finisher else "attack"
	if p_attack:
		queued_attack = true
	if t < w:
		_pose(anim, 0)
		vel.x = move_toward(vel.x, 0.0, 1500.0 * d)
	elif t < w + a:
		_pose(anim, 1)
		vel.x = facing * 140.0
		if not hit_done:
			hit_done = true
			_try_melee()
	elif t < w + a + r:
		_pose(anim, 2)
		vel.x = move_toward(vel.x, 0.0, 1500.0 * d)
		if queued_attack and combo_step < 3 and t > w + a + 0.06:
			_start_attack(combo_step + 1)
	else:
		_enter("idle")

func _try_melee() -> void:
	if opponent == null or opponent.state == "dead":
		return
	var mult: float = [1.0, 1.0, 1.7][combo_step - 1]
	var dmg: float = float(data["punch"]) * mult
	var box := Rect2(position.x + (10.0 if facing > 0 else -86.0), position.y - 104.0, 76.0, 64.0)
	if box.intersects(opponent.hurt_rect()):
		var heavy := combo_step == 3
		var kb := Vector2(facing * (520.0 if heavy else 180.0), -280.0 if heavy else -60.0)
		if opponent.take_hit(dmg, kb, 0.55 if heavy else 0.28, heavy):
			add_energy(dmg * 0.8)

func _start_cast(special: bool) -> void:
	cast_special = special
	_enter("cast")
	spawned = false
	vel.x = 0.0
	if special:
		energy = maxf(0.0, energy - 50.0)
		energy_changed.emit(energy)
	else:
		cd_blast = float(data["blast_cd"])

func _tick_cast(d: float) -> void:
	var wind := 0.35 if cast_special else 0.2
	vel.x = move_toward(vel.x, 0.0, 1500.0 * d)
	if t < wind:
		_pose("cast", 0)
		return
	if not spawned:
		spawned = true
		_fire()
	_pose("cast", 1 if t < wind + 0.12 else 2)
	if t >= wind + 0.28:
		_enter("idle")

func _fire() -> void:
	var p := Projectile.new()
	var dmg: float = float(data["special_dmg"]) if cast_special else float(data["blast_dmg"])
	p.setup(self, opponent, facing, dmg, float(data["blast_speed"]) * (1.15 if cast_special else 1.0),
		26.0 if cast_special else 13.0, data["color"], cast_special)
	p.position = position + Vector2(facing * 56.0, -78.0)
	spawn_projectile.emit(p)

func _tick_hurt(d: float) -> void:
	vel.x = move_toward(vel.x, 0.0, 500.0 * d)
	_pose("hurt", 0)
	if t >= stun_time and grounded:
		inv = 0.3
		_enter("idle")

# Returns true if the hit connected (false if blocked / ignored).
func take_hit(dmg: float, kb: Vector2, stun: float, heavy: bool) -> bool:
	if state == "dead" or inv > 0.0:
		return false
	var blocked := state == "block"
	if blocked:
		dmg *= 0.15
		vel.x = kb.x * 0.35
		add_energy(3.0)
	else:
		_enter("hurt")
		stun_time = stun
		vel = kb
		add_energy(dmg * 0.5)
	flash = 0.08
	hp = maxf(0.0, hp - dmg)
	hp_changed.emit(hp, max_hp)
	hit_landed.emit(Vector2(position.x, position.y - 70.0), heavy and not blocked, blocked)
	if hp <= 0.0:
		_enter("dead")
		died.emit(self)
	return not blocked
