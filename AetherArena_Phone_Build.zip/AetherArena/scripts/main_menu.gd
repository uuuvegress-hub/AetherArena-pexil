extends Control

var preview: AnimatedSprite2D
var char_btn: Button
var diff_btn: Button
var info: Label
var diffs := ["easy", "normal", "hard"]

func _ready() -> void:
	var v := get_viewport_rect().size
	var bg := TextureRect.new()
	bg.texture = load("res://arenas/crystal_valley/background.png")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var title := Label.new()
	title.text = "AETHER ARENA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiKit.outline_label(title, 60, Color(0.5, 0.9, 1.0))
	title.position = Vector2(0, 14)
	title.size = Vector2(v.x * 0.62, 80)
	add_child(title)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	box.position = Vector2(v.x * 0.31 - 170.0, 110)
	add_child(box)
	var fight := _btn("FIGHT", box)
	var train := _btn("TRAINING", box)
	char_btn = _btn("", box)
	diff_btn = _btn("", box)
	fight.pressed.connect(func():
		GameManager.mode = "fight"
		GameManager.goto("res://scenes/battle_arena.tscn"))
	train.pressed.connect(func():
		GameManager.mode = "training"
		GameManager.goto("res://scenes/battle_arena.tscn"))
	char_btn.pressed.connect(_cycle_char)
	diff_btn.pressed.connect(_cycle_diff)

	preview = AnimatedSprite2D.new()
	preview.scale = Vector2(5, 5)
	preview.position = Vector2(v.x * 0.78, 330)
	add_child(preview)
	info = Label.new()
	info.position = Vector2(v.x * 0.78 - 170.0, 345)
	info.size = Vector2(340, 150)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	UiKit.outline_label(info, 18)
	add_child(info)
	_refresh()

func _btn(text: String, parent: Node) -> Button:
	var b := Button.new()
	b.text = text
	UiKit.style_button(b)
	parent.add_child(b)
	return b

func _cycle_char() -> void:
	var ids := CharacterData.ids()
	var i := ids.find(GameManager.player_char)
	GameManager.player_char = ids[(i + 1) % ids.size()]
	_refresh()

func _cycle_diff() -> void:
	var i := diffs.find(GameManager.difficulty)
	GameManager.difficulty = diffs[(i + 1) % diffs.size()]
	_refresh()

func _refresh() -> void:
	var d: Dictionary = CharacterData.ROSTER[GameManager.player_char]
	char_btn.text = "FIGHTER: " + str(d["name"]).to_upper()
	diff_btn.text = "AI: " + GameManager.difficulty.to_upper()
	preview.sprite_frames = CharacterData.build_frames(GameManager.player_char)
	preview.play("idle")
	var s: Dictionary = d["stats"]
	info.text = "%s\nPower %d/5   Speed %d/5   Defense %d/5" % [d["desc"], s["Power"], s["Speed"], s["Defense"]]
