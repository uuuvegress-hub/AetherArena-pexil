"""Generates all original pixel-art assets for Aether Arena (run from project root: python3 tools/generate_assets.py)."""
import math, random, os
from PIL import Image, ImageDraw, ImageChops, ImageFilter

FW, FH = 48, 64
ROWS = ["idle","walk","jump","attack","attack2","hurt","block","cast","dead"]
COUNTS = dict(idle=4, walk=6, jump=2, attack=3, attack2=3, hurt=1, block=1, cast=3, dead=1)
OUTLINE = (16, 12, 28, 255)
CHARS = {
 "aether_knight": dict(skin=(241,205,176), main=(36,92,205), sec=(120,200,255), dark=(22,48,120), hair=(200,235,255), accent=(90,220,255), bulk=1.0),
 "inferno": dict(skin=(226,160,120), main=(170,36,28), sec=(255,150,40), dark=(96,18,20), hair=(255,110,20), accent=(255,210,80), bulk=1.25),
}

def P(p): return (int(round(p[0])), int(round(p[1])))
def pt(a, ang, ln):
    r = math.radians(ang); return (a[0] + ln*math.sin(r), a[1] + ln*math.cos(r))
def seg(d, a, b, w, col):
    d.line([P(a), P(b)], fill=col, width=w)
    r = w/2.0
    d.ellipse([b[0]-r, b[1]-r, b[0]+r, b[1]+r], fill=col)
def limb(d, p, angs, l1, l2, w, c1, c2, end=None):
    k = pt(p, angs[0], l1); e = pt(k, angs[1], l2)
    seg(d, p, k, w, c1); seg(d, k, e, max(2, w-1), c2)
    if end:
        d.ellipse([e[0]-end[0], e[1]-end[0], e[0]+end[0], e[1]+end[0]], fill=end[1])
    return e
def foot_y(angs): return 11*math.cos(math.radians(angs[0])) + 11*math.cos(math.radians(angs[1]))

def outline(img):
    a = img.split()[3].point(lambda v: 255 if v > 0 else 0)
    dil = a.filter(ImageFilter.MaxFilter(3))
    mask = ImageChops.subtract(dil, a)
    res = img.copy(); res.paste(Image.new("RGBA", img.size, OUTLINE), (0, 0), mask)
    return res

def draw_fighter(pose, c, name):
    img = Image.new("RGBA", (FW, FH), (0,0,0,0)); d = ImageDraw.Draw(img)
    bulk = c["bulk"]; lw = round(4*bulk); aw = round(3*bulk)
    hy = pose.get("hy")
    if hy is None:
        hy = 61 - max(foot_y(pose["fl"]), foot_y(pose["bl"])) + pose.get("air", 0)
    hx = pose["hx"]; t = math.radians(pose["tilt"])
    up = (math.sin(t), -math.cos(t)); perp = (math.cos(t), math.sin(t))
    hip = (hx, hy); sh = (hx + 18*up[0], hy + 18*up[1]); tw = 6.0*bulk
    limb(d, sh, pose["ba"], 8, 8, aw, c["dark"], c["skin"], (2, c["sec"]))
    limb(d, hip, pose["bl"], 11, 11, lw, c["dark"], c["dark"], (2.5, c["sec"]))
    poly = [(sh[0]-perp[0]*tw, sh[1]-perp[1]*tw), (sh[0]+perp[0]*tw, sh[1]+perp[1]*tw),
            (hip[0]+perp[0]*(tw-1.5), hip[1]+perp[1]*(tw-1.5)), (hip[0]-perp[0]*(tw-1.5), hip[1]-perp[1]*(tw-1.5))]
    d.polygon([P(p) for p in poly], fill=c["main"])
    d.line([P(sh), P(hip)], fill=c["sec"], width=2)
    d.line([P((hip[0]-perp[0]*(tw-1), hip[1]-perp[1]*(tw-1))), P((hip[0]+perp[0]*(tw-1), hip[1]+perp[1]*(tw-1)))], fill=c["accent"], width=2)
    ho = pose.get("head", (0, 0))
    hc = (sh[0] + up[0]*7 + ho[0], sh[1] + up[1]*7 + ho[1])
    if name == "inferno":
        for dx, h in ((-4, 9), (0, 12), (4, 9)):
            d.polygon([P((hc[0]+dx-3, hc[1]-4)), P((hc[0]+dx+3, hc[1]-4)), P((hc[0]+dx*1.3, hc[1]-4-h))], fill=c["hair"])
            d.point(P((hc[0]+dx*1.3, hc[1]-3-h)), fill=c["accent"])
    d.ellipse([hc[0]-6, hc[1]-6, hc[0]+6, hc[1]+6], fill=c["skin"])
    d.pieslice([hc[0]-6, hc[1]-6, hc[0]+6, hc[1]+6], 180, 360, fill=c["hair"])
    if name == "aether_knight":
        d.polygon([P((hc[0]-5, hc[1]-3)), P((hc[0]-13, hc[1]-6)), P((hc[0]-6, hc[1]-6))], fill=c["hair"])
        d.polygon([P((hc[0]-5, hc[1]-1)), P((hc[0]-12, hc[1]+1)), P((hc[0]-6, hc[1]-3))], fill=c["hair"])
        d.line([P((hc[0]-6, hc[1]-1)), P((hc[0]+6, hc[1]-1))], fill=c["accent"], width=1)
        d.line([P(sh), P((sh[0]-9, sh[1]+2))], fill=c["sec"], width=2)
        d.line([P(sh), P((sh[0]-7, sh[1]+5))], fill=c["accent"], width=2)
    d.rectangle([P((hc[0]+1.5, hc[1]+0.5)), P((hc[0]+3, hc[1]+1.5))], fill=(20, 20, 40) if not pose.get("glow") else c["accent"])
    fe = limb(d, hip, pose["fl"], 11, 11, lw, c["dark"], c["dark"], (2.5, c["sec"]))
    ae = limb(d, sh, pose["fa"], 8, 8, aw, c["main"], c["skin"], (2.2, c["sec"]))
    if pose.get("glow"):
        r = pose["glow"]
        d.ellipse([ae[0]-r, ae[1]-r, ae[0]+r, ae[1]+r], fill=c["accent"])
        d.ellipse([ae[0]-r/2, ae[1]-r/2, ae[0]+r/2, ae[1]+r/2], fill=(255, 255, 255))
    fx = pose.get("fx")
    if fx:
        e = ae if fx == "punch" else fe
        for dy in (-4, 0, 4):
            d.line([P((e[0]+3, e[1]+dy)), P((e[0]+8, e[1]+dy*1.5))], fill=c["accent"], width=1)
    return outline(img)

def mk(**k):
    b = dict(hx=24, tilt=4, fa=(55,140), ba=(35,125), fl=(18,6), bl=(-18,-8), head=(0,0)); b.update(k); return b
POSES = {}
POSES["idle"] = [mk(tilt=4+i*0.5, fa=(55+i*2,140+i*2), ba=(35+i*2,125+i*2), fl=(18,6+i*3), bl=(-18,-8-i*2)) for i in (0,1,2,1)]
POSES["walk"] = []
for i in range(6):
    p = i/6*2*math.pi; s = math.sin(p); co = math.cos(p)
    POSES["walk"].append(mk(tilt=7, fl=(30*s, 30*s-22*max(0,co)), bl=(-30*s, -30*s-22*max(0,-co)), fa=(55-10*s,140), ba=(35+10*s,125)))
POSES["jump"] = [mk(fl=(50,-20), bl=(-10,-45), fa=(150,170), ba=(120,160), air=-6), mk(fl=(20,5), bl=(-15,-10), fa=(95,100), ba=(75,90), air=-6)]
POSES["attack"] = [mk(hx=22, tilt=-6, fa=(-35,-70), ba=(70,150)),
                   mk(hx=28, tilt=14, fa=(92,92), ba=(30,120), fl=(40,15), fx="punch"),
                   mk(hx=25, tilt=6, fa=(70,140), ba=(40,125))]
POSES["attack2"] = [mk(tilt=-10, fl=(70,-30), fa=(60,140), ba=(40,125)),
                    mk(hx=14, tilt=-18, fl=(92,92), bl=(-5,-5), fa=(-30,-60), ba=(-20,-50), fx="kick"),
                    mk(tilt=2, fl=(40,0))]
POSES["hurt"] = [mk(hx=22, tilt=-22, head=(-2,1), fa=(-30,-70), ba=(-50,-90), fl=(10,0), bl=(-25,-30))]
POSES["block"] = [mk(tilt=8, fa=(70,170), ba=(55,165), fl=(30,25), bl=(-25,-30))]
POSES["cast"] = [mk(tilt=-10, fa=(-60,-85), ba=(-50,-80), glow=3),
                 mk(tilt=12, fa=(90,90), ba=(80,85), glow=6),
                 mk(tilt=12, fa=(90,90), ba=(80,85), glow=4)]
POSES["dead"] = [mk(hx=38, hy=56, tilt=-86, fa=(-100,-100), ba=(-80,-90), fl=(75,-20), bl=(60,-30), head=(0,2))]

def make_sheet(name):
    sheet = Image.new("RGBA", (FW*6, FH*len(ROWS)), (0,0,0,0))
    for r, row in enumerate(ROWS):
        assert len(POSES[row]) == COUNTS[row], row
        for cidx, pose in enumerate(POSES[row]):
            sheet.paste(draw_fighter(pose, CHARS[name], name), (cidx*FW, r*FH))
    return sheet

def make_bg():
    W, H = 320, 135; rnd = random.Random(7)
    img = Image.new("RGBA", (W, H)); d = ImageDraw.Draw(img)
    for y in range(118):
        k = y/118; d.line([(0,y),(W,y)], fill=(int(18+55*k), int(10+34*k), int(46+80*k), 255))
    for _ in range(70):
        x, y = rnd.randrange(W), rnd.randrange(80); d.point((x,y), fill=(220,220,255,255) if rnd.random()<.5 else (150,150,220,255))
    d.ellipse([240,12,266,38], fill=(235,235,255,255)); d.ellipse([250,20,255,25], fill=(200,200,235,255)); d.ellipse([258,28,262,32], fill=(205,205,235,255))
    for col, base, amp in (((44,30,92,255), 88, 22), ((32,22,70,255), 100, 14)):
        pts = [(0,H)]; x = 0
        while x <= W:
            pts.append((x, base - rnd.randrange(0, amp))); x += rnd.randrange(14, 34)
        pts += [(W, base), (W, H)]; d.polygon(pts, fill=col)
    for i in range(16):
        x = 8 + i*20 + rnd.randrange(-6, 6); h = rnd.randrange(14, 34); w = rnd.randrange(6, 11)
        c1, c2 = ((70,220,255,255),(160,245,255,255)) if i%3 else ((220,90,240,255),(250,170,255,255))
        d.polygon([(x,118),(x+w,118),(x+w//2+1,118-h)], fill=c1)
        d.polygon([(x,118),(x+w//2,118),(x+w//2+1,118-h)], fill=c2)
    for x, h in ((4,52),(300,60)):
        d.polygon([(x,118),(x+14,118),(x+8,118-h)], fill=(120,60,200,255)); d.polygon([(x,118),(x+7,118),(x+8,118-h)], fill=(190,130,255,255))
    fog = Image.new("RGBA", (W,H), (0,0,0,0)); ImageDraw.Draw(fog).rectangle([0,100,W,118], fill=(170,140,255,45))
    img = Image.alpha_composite(img, fog); d = ImageDraw.Draw(img)
    d.rectangle([0,118,W,H], fill=(52,44,86,255)); d.line([(0,118),(W,118)], fill=(150,140,205,255)); d.line([(0,119),(W,119)], fill=(104,94,160,255))
    for x in range(0, W, 20): d.line([(x,120),(x,H)], fill=(36,30,64,255))
    for y in (126,132): d.line([(0,y),(W,y)], fill=(36,30,64,255))
    for _ in range(60): d.point((rnd.randrange(W), rnd.randrange(121,H)), fill=(74,64,114,255))
    return img.resize((W*4, H*4), Image.NEAREST)

def make_btn(pressed):
    s = 24; img = Image.new("RGBA", (s,s), (0,0,0,0)); d = ImageDraw.Draw(img)
    fill = (70,120,210,255) if pressed else (24,32,70,255)
    d.ellipse([0,0,s-1,s-1], fill=(120,200,255,255)); d.ellipse([2,2,s-3,s-3], fill=fill)
    return img.resize((96,96), Image.NEAREST)

if __name__ == "__main__":
    for n in CHARS:
        os.makedirs(f"characters/{n}", exist_ok=True); make_sheet(n).save(f"characters/{n}/sheet.png")
    os.makedirs("arenas/crystal_valley", exist_ok=True); make_bg().save("arenas/crystal_valley/background.png")
    os.makedirs("ui", exist_ok=True); make_btn(False).save("ui/btn.png"); make_btn(True).save("ui/btn_down.png")
    ic = Image.new("RGBA", (128,128), (30,20,70,255)); f = draw_fighter(POSES["idle"][0], CHARS["aether_knight"], "aether_knight").resize((96,128), Image.NEAREST)
    ic.paste(f, (16,0), f); ic.save("icon.png")
    pv = Image.new("RGBA", (FW*6*2*2, FH*len(ROWS)*2), (60,60,90,255))
    for i, n in enumerate(CHARS):
        s = Image.open(f"characters/{n}/sheet.png").resize((FW*6*2, FH*len(ROWS)*2), Image.NEAREST); pv.paste(s, (i*FW*6*2, 0), s)
    pv.save("/home/claude/preview_sheets.png")
    print("assets ok")
